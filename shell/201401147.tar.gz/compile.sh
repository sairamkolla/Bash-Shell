gcc -g execution.c main.c tokenize.c refresh.c -o a.out
