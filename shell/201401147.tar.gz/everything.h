#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<signal.h>
#include<sys/utsname.h>
#include<sys/wait.h>
#include<stdbool.h>
