#include "everything.h"
#include "tokenize.h"
//char home11[100]="/home/";
void free_shit(char **a){
	int i;
	for(i=0;a[i]!=NULL;i++){
		free(a[i]);
		a[i]=NULL;
	}
	return ;
}
void final(char **command,char *home11);
void final1(char **command,char *home11);
void spawn_proc (int in, int out, char *singlepipe,char *home){//struct command *cmd)
	pid_t pid;
	char space[2]=" ";
	int status=0;
	/*//pid=fork();
	//if (pid== 0){
		//status=status;
		if (in != 0){
			dup2(in, 0);
			close(in);
		}
		if (out != 1){
			dup2 (out, 1);
			close (out);
		}*/
		char **args;
		tokenize(singlepipe,&args,space);
		final(args,home);
		//execvp(args[0],(args));
		free_shit(args);
	//}
	//else 
	//	wait(NULL);

	return ;
}
void fork_pipes (char **command,char *home)
{
	int i;
	pid_t pid;
	int in, fd [2];
	char **args;
	char space[2]=" ";
	in = 0;
	dup2(in,0);
	for (i = 0; command[i+1]!=NULL; i++){
		printf("present command is %s\n",command[i]);
		
		pipe(fd);
		if(in!=0){
			dup2(in,0);
			close(in);
		}
		if(fd[1]!=1){
			dup2(fd[1],1);
			close(fd[1]);
		}
		//dup2(fd[0],in);
	
		//**** Execution section

		//spawn_proc (fd[0], fd [1],command[i],home);
		tokenize(command[i],&args,space);
		//final(args,home);
		execvp(args[0],(args));
		
		// execution completed

		close(fd[1]);
		printf("%s is sucessfully executed\n",command[i]);
		//close (fd [1]);
		//dup2(in,fd [1]);
		in=fd[0];
		//close(fd[1]);
		//in=fd[1];
	}
	//dup2(in,0);
	if (in != 0)
		dup2 (in, 0);
	tokenize(command[i],&args,space);
	execvp(args[0],(args));
	//final(args,home);
	//free_shit(args);
	return;
}
void present_direc(){
	char cwd[100];
	printf("%s\n",getcwd(cwd,sizeof(cwd)));
	return;
}
void final(char **command,char *home11){
	printf("To execute %s\n",command[0]);
	char pwd[4]="pwd";
	char cd[3]="cd";
	char echo[5]="echo";
	//inchild=0;
	int arg_i=1;
	int is_background=0;
	/*char andand[2]="&";
	  if(strcmp(command[no_of_args-1],andand)==0){
	  is_background=1;//printf("Background\n");
	  command[no_of_args-1]=NULL;
	  }*/
	//int status=0;
	pid_t pid,wpid;
	pid=fork();
	if(pid==0){
		if(strcmp(command[0],pwd)==0)
			present_direc();
		else if( strcmp(command[0],cd)==0){
			if(command[1]==NULL || command[1][0]=='~'){
				printf("%s\n",home11);
				command[1]=(char*)malloc((strlen(home11)+1)*sizeof(char));
				strcpy(command[1],home11);

				//printf("%s\n",home11);
			}
			//printf("%s\n",command[1]);	
			if(chdir(command[1])!=0)
				printf("The Specifed Path Doesn't exist\n");
			else
				printf("sucess\n");

		}
		else if(strcmp(command[0],echo)==0){
			while(command[arg_i]!=NULL){
				printf("%s ",command[arg_i]);
				arg_i++;
			}		
			printf("\n");
		}
		else if(execvp(command[0],(command))==-1){
			perror("error\n");
			exit(EXIT_FAILURE);
		}
		//start();
	}
	else if (pid<0)
		perror("shit!!");
	else{
		/*if(!is_background)
		  do {
		  waitpid(pid, &status, WUNTRACED);
		  } while (!WIFEXITED(status) && !WIFSIGNALED(status));

		  is_background=0;*/
		wait(NULL);
	}
	return ;
}
void final1(char **command,char *home11){
	printf("To execute %s\n",command[0]);
	char pwd[4]="pwd";
	char cd[3]="cd";
	char echo[5]="echo";
	//inchild=0;
	int arg_i=1;
	int is_background=0;
	/*char andand[2]="&";
	  if(strcmp(command[no_of_args-1],andand)==0){
	  is_background=1;//printf("Background\n");
	  command[no_of_args-1]=NULL;
	  }*/
	//int status=0;
	pid_t pid,wpid;
		if(strcmp(command[0],pwd)==0)
			present_direc();
		else if( strcmp(command[0],cd)==0){
			if(command[1]==NULL || command[1][0]=='~'){
				printf("%s\n",home11);
				command[1]=(char*)malloc((strlen(home11)+1)*sizeof(char));
				strcpy(command[1],home11);

				//printf("%s\n",home11);
			}
			//printf("%s\n",command[1]);	
			if(chdir(command[1])!=0)
				printf("The Specifed Path Doesn't exist\n");
			else
				printf("sucess\n");

		}
		else if(strcmp(command[0],echo)==0){
			while(command[arg_i]!=NULL){
				printf("%s ",command[arg_i]);
				arg_i++;
			}		
			printf("\n");
		}
		else if(execvp(command[0],(command))==-1){
			perror("error\n");
			exit(EXIT_FAILURE);
		}
		//start();
	return ;
}
