void fork_pipes(char **,char *);
void final(char **,char *);
