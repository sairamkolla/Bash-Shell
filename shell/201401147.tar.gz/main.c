#include "everything.h"
#include "refresh.h"
#include "tokenize.h"
#include "execution.h"
char home[100]="/home/";
void describe(char **a){
	int i;
	for(i=0;a[i]!=NULL;i++)
		printf("%d--> %s\n",i,a[i]);
	return ;
}
void handle_signal(int signo){
	printf("\n");
	start(home);
	fflush(stdout);
	return ;

}
int main(){
	strcat(home,getlogin());
	signal(SIGINT, SIG_IGN);
	signal(SIGINT,handle_signal);


	char line[100];
	bzero(line,sizeof(line));
	int index=0,i;

	//**************** Delimiters
	char collen[2]=";";
	char space[2]=" ";
	char pipesymbol[2]="|";
	//******************* End of Delimiters

	//********** pipes,arguments,multiplecommands
	char **mult;
	char **args;
	char **pipe_parts;
	//***********
	

	char c='\0';
	while(c!=EOF){
		c=getchar();
		switch(c){
			case '\n':
				if(!line[0]=='\0'){
					tokenize(line,&mult,collen);

					describe(mult);
					for(i=0;mult[i]!=NULL;i++){
						
						//Assignment phase 2
						
						//tokenize(mult[i],&pipe_parts,pipesymbol);
						//describe(pipe_parts);
						//fork_pipes(pipe_parts,home);

						//Assignment Phase 1

						tokenize(mult[i],&args,space);
						final(args,home);
					}

					index=0;
					bzero(line,sizeof(line));
				}
				start(home);
				break;
			default:
				line[index++]=c;	
		}


	}
	return 0;
}
