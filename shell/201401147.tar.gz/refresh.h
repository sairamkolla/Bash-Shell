#include<stdio.h>
void start(char *);
